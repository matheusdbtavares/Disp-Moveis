package com.impacta.listadecompras;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Matheus Domingos Bahia Tavares - RA: 1520180;
 * Caio Makoto Yonamine - RA: 1520359.
 */

public class ProdutoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produto);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        nomeProd = (EditText) findViewById(R.id.nomeProd);
        valorProd = (EditText) findViewById(R.id.valorProd);
        catProd = (EditText) findViewById(R.id.catProd);
        btnSalvar = (Button) findViewById(R.id.btnSalvar);
        mDatabaseHelper = new DatabaseHelper(this);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newEntry = nomeProd.getText().toString();
                double newEntry2 = Double.parseDouble(valorProd.getText().toString());
                String newEntry3 = nomeProd.getText().toString();
                if (nomeProd.getText().length() == 0 ||
                        valorProd.getText().length() == 0 || catProd.getText().length() == 0) {
                    AddData(newEntry, newEntry2, newEntry3);
                    nomeProd.setText("");
                    valorProd.setText("");
                    catProd.setText("");
                } else {
                    toastMessage("Você precisa colocar algo no campo!");
                }

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_remover) {

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private static final String TAG = "ProdutoActivity";

    DatabaseHelper mDatabaseHelper;
    Button btnSalvar;
    EditText nomeProd, valorProd, catProd;


    public void AddData(String newEntry, double newEntry2, String newEntry3) {
        boolean insertData = mDatabaseHelper.addData(newEntry);

        if (insertData) {
            toastMessage("Dados inseridos com sucesso!");
        } else {
            toastMessage("Algo deu errado");
        }
    }

    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

}
